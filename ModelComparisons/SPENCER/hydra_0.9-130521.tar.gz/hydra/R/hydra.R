
hydra.source <<- ""
hydra.job.id <<- 1

hydra.resources <<- list()

hydra.running <<- list()
hydra.queue <<- list()

hydra.shadow.mode <<- F
hydra.status.file <<- NULL

hydra.script.dir <<- "~"

hydraInit <- function(local=1, shadow.mode=F, ..., splash=T, status.file=NULL, script.dir=getwd()){

  # Initialises the hydra
  #
  # local: The number of local processes to spawn
  #
  # Additional arguments are treated as additional processing
  # resource names. There needs to be corresponding launch-<name>.sh
  # and collect-<name>.sh (or .bat on windows) files present
  # or an error will be generated. These .sh file can be customised
  # to push the processing to different places (i.e. a grid)

  hydra.source <<- ""
  hydra.resources <<- list(local=local, ...)
  hydra.job.id <<- 1
  hydra.shadow.mode <<- shadow.mode
  hydra.status.file <<- status.file
  hydra.script.dir <<- script.dir

  hydra.running <<- list()
  hydra.queue <<- list()

  if (sum(unlist(hydra.resources)) == 0)
    stop("Total processing resources made available is zero")
  
  is.windows <- (Sys.info()["sysname"] == "Windows")
  
  if (is.windows) {
    suffix <- ".bat"
  } else {
    suffix <- ".sh"
  }

  if (length(hydra.resources) > 0) {
    for (resource in names(hydra.resources)) {
      launch.exe  <- paste(hydra.script.dir, "/launch-", resource, suffix, sep="")
      collect.exe <- paste(hydra.script.dir, "/collect-", resource, suffix, sep="")
      
      if ( ! file.exists(launch.exe))
        stop(paste("file", launch.exe, "not found!"))
        
      if ( ! file.exists(collect.exe))
        stop(paste("file", collect.exe, "not found!"))
        
      hydra.running[[resource]] <<- list()
    }
  }

  dir.create("hydra-tmp", showWarnings=F)

  if (splash)
    hydraSplash()
}

hydraCollect <- function(job.id = NULL, timeout=0) {

  # Collects the results from hydraRun calls
  #
  # Args:
  #    job.id: The ID of the job, if NULL returns all finished jobs
  #   timeout: The amount of time to wait for jobs to finish
  #
  # Returns:
  #   A list containing the results

  collect <- function(resource, job.id) {

    result <- NULL
    pid <- Sys.getpid()
    is.windows <- (Sys.info()["sysname"] == "Windows")

    file.name <- sprintf("z%04d%05d", pid %% 10000, job.id %% 100000)

    tmp.file    <- paste(file.name, "-t.RData", sep="")
    out.file    <- paste(file.name, "-o.RData", sep="")
    in.file     <- paste(file.name, "-i.RData", sep="")
    script.file <- file.name

    return.code <- 0
      
    if (is.windows) {
      collect.exe <- paste(hydra.script.dir, "/collect-", resource, ".bat", sep="")
      shell(paste(collect.exe, script.file, in.file, tmp.file, out.file))
    } else {
      collect.exe <- paste(hydra.script.dir, "/collect-", resource, ".sh", sep="")
      return.code <- system(paste("bash", collect.exe, script.file, in.file, tmp.file, out.file, " 2>>/dev/null"))
    }
    
    if (file.exists(paste("hydra-tmp", out.file, sep="/"))) {
    
      print(paste("job.id", job.id, "collected"), quote=F)

      load(paste("hydra-tmp", out.file, sep="/"))
    
      if (class(r) != "try-error") {
        file.remove(paste("hydra-tmp", out.file, sep="/"))
        file.remove(paste("hydra-tmp", in.file, sep="/"))
        file.remove(paste("hydra-tmp", script.file, sep="/"))
      } else {
        print(paste("job.id", job.id, "shat itself"), quote=F)
        print(r)
      }

      result <- r
    }

    list(return.code=return.code, result=result)
  }

  results <- list()
  finished <- F
  start.time <- Sys.time()

  repeat {

    if ( ! is.null(job.id)) {
  
      for (resource in names(hydra.running)) {
        if (job.id %in% as.integer(names(hydra.running[[resource]]))) {
          result <- collect(resource, job.id)
          results[[as.character(job.id)]] <- result$result
          if ( ! is.null(result$result)) {
		  
            for (r in hydra.running) {
              if (as.character(job.id) %in% names(hydra.running[[r]]))
                hydra.running[[r]][[as.character(job.id)]] <<- NULL
            }
            finished <- T
            break
          } else {
            finished <- F
          }
        } else {
          results[[as.character(job.id)]] <- NULL
          finished <- T
        }

        hydraLaunchQueue(shadow=(timeout > 0))
      }
      
    } else {
    
      for (resource in names(hydra.running)) {

        for (job.id in as.integer(names(hydra.running[[resource]]))) {

          result <- collect(resource, job.id)

          is.ares <- Sys.info()["nodename"] == "ares"  # hack for ares

          if ( ! is.null(result$result)) {

            results[[as.character(job.id)]] <- result$result
            hydra.running[[resource]][[as.character(job.id)]] <<- NULL

            hydraLaunchQueue(shadow=(timeout > 0))

          
          } else if (result$return.code == 1 || (is.ares && result$return.code == 256)) {

            if ( ! "time" %in% names(hydra.running[[resource]][[as.character(job.id)]])) {
              print("job pending")
              hydra.running[[resource]][[as.character(job.id)]]$time <<- Sys.time()
            } else if ( as.numeric(Sys.time() - hydra.running[[resource]][[as.character(job.id)]]$time, units="secs") > 60) {

              print("job failed and rescheduled")
            
              job <- list()
              job[[as.character(job.id)]] <- hydra.running[[resource]][[as.character(job.id)]]
              hydra.queue[[as.character(job.id)]] <<- c(job, hydra.queue[[as.character(job.id)]])
              hydra.running[[resource]][[as.character(job.id)]] <<- NULL

              hydraLaunchQueue(shadow=(timeout > 0))
            }
          }
        }
      }

      finished <- T

      for (running in hydra.running) {
        if (length(running) > 0) {
          finished <- F
          break
        }
      }

      job.id <- NULL
    }

    if (finished)
      break

    if (difftime(Sys.time(), start.time, units="secs") > timeout)
      break
  }

  if (length(results) > 0) {
    sorted.results <- list()
    for (job.id in sort(as.integer(names(results))))
      sorted.results[[as.character(job.id)]] = results[[as.character(job.id)]]
    return(sorted.results)
  } else {
    hydraLaunchQueue(shadow=T)
    return(list())
  }
}


hydraSource <- function(filename) {
  # Equivalent to running source() on the processing nodes

  hydra.source <<- c(hydra.source, paste(scan(filename, what="character", sep="\n"), sep="\n"))

}

hydraJobsLeft <- function() {

  jobs.left <- length(hydra.queue)

  for (r in names(hydra.running))
    jobs.left <- jobs.left + length(hydra.running[[r]])

  jobs.left
}

hydraLaunchQueue <- function(shadow=T) {

  is.windows <- (Sys.info()["sysname"] == "Windows")
  pid <- Sys.getpid()

  if (is.windows) {
    suffix <- ".bat"
  } else {
    suffix <- ".sh"
  }

  while (length(hydra.queue) > 0) {

    resource <- NULL

    for (r in names(hydra.resources)) {
      if (hydra.resources[[r]] > length(hydra.running[[r]])) {
        resource <- r
        break
      }
    }
  
    if (is.null(resource))  # no available resource
      break

    job.id <- as.integer(names(hydra.queue)[[1]])
    job    <- hydra.queue[[1]]
    hydra.queue[[1]] <<- NULL

    if (is.null(job$job.name)) {
      print(paste("job.id", job.id, "started"), quote=F)
    } else {
      print(paste("job.id", job.id, "started (", job$job.name, ")"), quote=F)
    }

    file.name <- sprintf("z%04d%05d", pid %% 10000, job.id %% 100000)

    tmp.file    <- paste(file.name, "-t.RData", sep="")
    out.file    <- paste(file.name, "-o.RData", sep="")
    in.file     <- paste(file.name, "-i.RData", sep="")
    script.file <- file.name
    
    if (is.windows) {
      launch.exe <- paste(hydra.script.dir, "/launch-", resource, ".bat", sep="")
      option.args <- paste(job$options, collapse=" ")
      exe <- paste(launch.exe, script.file, in.file, tmp.file, out.file, job$est.time, option.args)
      shell(exe, wait=F)
    } else {
      launch.exe <- paste(hydra.script.dir, "/launch-", resource, ".sh", sep="")
      option.args <- paste(job$options, collapse=" ")
      exe <- paste("bash", launch.exe, script.file, in.file, tmp.file, out.file, job$est.time, option.args)
      system(exe, wait=(resource != "local"))
    }

    hydra.running[[resource]][[as.character(job.id)]] <<- job

    hydraWriteStatus()
  }

}

hydraRun <- function(fun, ..., job.name=NULL, est.time=3600, options="") {

  # Executes a function asynchronously. Results are obtained through
  # calling hydraCollect()
  #
  # Args:
  #     fun: The function to execute
  #     ...: The arguments to pass to he function
  #
  # Returns:
  #   A job.id

  job.id <<- hydra.job.id
  pid <- Sys.getpid()

  file.name <- sprintf("z%04d%05d", pid %% 10000, job.id %% 100000)
	
  in.file     <- paste(file.name, "-i.RData", sep="")
  tmp.file    <- paste(file.name, "-t.RData", sep="")
  script.file <- file.name
  
  v <- list(...)
  save(list  = c("v"),
    file  = paste("hydra-tmp", in.file, sep="/"))

  sink(file=paste("hydra-tmp", script.file, sep="/"), append=T, type="output")
    
  cat(paste("load(file=", in.file, ")\n", sep="\""))
  cat("setwd('..')")
  cat(hydra.source, sep="\n")
  
  cat("r <- try({ do.call( ")
  cat(deparse(fun), sep="\n")
  cat(", v)} )\n")
  cat("setwd('hydra-tmp')\n")
  cat(paste("save(r, file=", tmp.file, ")\n", sep="\""))
    
  sink()
  
  i <- length(hydra.queue) + 1
  hydra.queue[[as.character(job.id)]] <<- list(job.name=job.name, est.time=est.time, options=options)
  hydra.job.id <<- hydra.job.id + 1

  hydraLaunchQueue(shadow=F)
  
  job.id
}


hydraLapply <- function(X, FUN, ..., est.time=3600, options="") {

  # Equivalent to lapply, but with processing spread across nodes
  #
  # Args:
  #       X: A vector containing the elements to pass to the function
  #     FUN: The function to execute over the vector
  #
  # Returns:
  #   The results

  job.ids <- c()
  results <- c()

  for (v in X) {
    job.ids <- c(job.ids, hydraRun(FUN, v, ..., est.time=est.time, options=options))
  }

  error <- NULL

  for (job.id in job.ids) {
    result <- hydraCollect(job.id, timeout=Inf)
    if (class(result) == "try-error")
      error <- result
    if (is.null(error))
      results <- c(results, result)
  }

  if ( ! is.null(error))
    stop(error)

  results
}

hydraWriteStatus <- function() {

  if (is.null(hydra.status.file))
    return()

  tryCatch({

  sink(file=hydra.status.file)

  cat("<html><head><title>hydra</title><meta http-equiv=\"refresh\" content=\"10\" /></head><body>")
  cat("<table>")

  jobs <- unlist(hydra.running)
  items.being.shadowed <- jobs[duplicated(jobs)]

  for (resource in names(hydra.running)) {
    for (job.id in hydra.running[[resource]]) {
      if (resource == "local") {
        if (job.id %in% items.being.shadowed) {
          status <- "shadowing locally"
        } else {
          status <- "running locally"
        }
      } else {
        status <- paste("submitted to", resource)
      }
      cat("<tr>")
      cat(paste("<td>", job.id,   "</td>"))
      cat(paste("<td>", status, "</td>"))
      cat("</tr>")
    }
  }

  for (job.id in as.integer(names(hydra.queue))) {
    cat("<tr>")
    cat(paste("<td>", job.id,     "</td>"))
    cat(paste("<td>", "in queue", "</td>"))
    cat("</tr>")    
  }
  
  cat("</table>")
  cat("</body></html>")

  }, error = function(e) { hydra.status.file <<- NULL })

  sink()

}

hydraSplash <- function() {
  print('                                        ,   ,', quote=F)
  print('                                        $,  $,     ,', quote=F)
  print('                                        "ss.$ss. .s\'', quote=F)
  print('                                ,     .ss$$$$$$$$$$s,', quote=F)
  print('                                $. s$$$$$$$$$$$$$$`$$Ss', quote=F)
  print('                                "$$$$$$$$$$$$$$$$$$o$$$       ,', quote=F)
  print('                               s$$$$$$$$$$$$$$$$$$$$$$$$s,  ,s', quote=F)
  print('                              s$$$$$$$$$"$$$$$$""""$$$$$$"$$$$$,', quote=F)
  print('                              s$$$$$$$$$$s""$$$$ssssss"$$$$$$$$"', quote=F)
  print('                             s$$$$$$$$$$\'         `"""ss"$"$s""', quote=F)
  print('                             s$$$$$$$$$$,              `"""""$  .s$$s', quote=F)
  print('                             s$$$$$$$$$$$$s,...               `s$$\'  `', quote=F)
  print('                         `ssss$$$$$$$$$$$$$$$$$$$$####s.     .$$"$.   , s-', quote=F)
  print('                           `""""$$$$$$$$$$$$$$$$$$$$#####$$$$$$"     $.$\'', quote=F)
  print('                                 "$$$$$$$$$$$$$$$$$$$$$####s""     .$$$|', quote=F)
  print('                                  "$$$$$$$$$$$$$$$$$$$$$$$$##s    .$$" $', quote=F)
  print('                                   $$""$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"   `', quote=F)
  print('                                  $$"  "$"$$$$$$$$$$$$$$$$$$$$S""""\'', quote=F)
  print(' Hydra 2011-10-29            ,   ,"     \'  $$$$$$$$$$$$$$$$####s', quote=F)
  print('                             $.          .s$$$$$$$$$$$$$$$$$####"', quote=F)
}
